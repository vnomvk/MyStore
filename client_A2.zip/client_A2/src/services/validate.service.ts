import { Injectable } from '@angular/core';
import {Http,Headers} from '@angular/http';

import {Observable} from 'rxjs/Rx';
//For server data access and send back the objects
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()

export class ValidateService {
	myMedia_token:string;
	myMedia_user:Object;

	constructor(private http:Http) {
				
	}

	userSignup(user) {
		let headers=new Headers();
		headers.append('Content-Type','application/json');
		return this.http.post('http://localhost:5004/api/signupData',user,{headers:headers}).map(res=>res.json());
	}

	userLogin(user) {
		let headers=new Headers();
		headers.append('Content-Type','application/json');
		return this.http.post('http://localhost:5004/api/loginData',user,{headers:headers}).map(res=>res.json());
	}

	sotreUserData(token,user){
		sessionStorage.setItem("myMedia_token",token);
		sessionStorage.setItem("myMedia_user",JSON.stringify(user));
		this.myMedia_token=token;
		this.myMedia_user=user;
		
	}

	userLogout(){
		sessionStorage.removeItem("myMedia_token");
		sessionStorage.removeItem("myMedia_user");
		this.myMedia_token=null;
		this.myMedia_user={};
		return;
	}
}