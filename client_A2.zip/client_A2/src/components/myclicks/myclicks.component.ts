import { Component } from '@angular/core';

@Component({
  selector: 'myclicks',
  templateUrl: './myclicks.component.html',
  
})

export class MyClicksComponent { }