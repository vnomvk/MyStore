import { Component , OnInit, OnChanges } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import {FlashMessagesService} from 'angular2-flash-messages';
import {ValidateService} from'../../services/validate.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit{ 
//Credential Variables
	userName:string;
	passWord:string;


	constructor(private router: Router,private flashMessage:FlashMessagesService,
		private validateService:ValidateService) {
	}

	ngOnInit(){
		this.userName='';
		this.passWord='';
	}
	onLogin(e) {
		e.preventDefault();
		let user={
				userName:this.userName,
				passWord:this.passWord
			}
		if(this.passWord==''){
			this.flashMessage.show('Please verify your credential!!!',{cssClass:'alert-danger',timeout:1500});
		}
		else{
			this.validateService.userLogin(user).subscribe(data => {
			
				if(!data.success){
					this.router.navigate(['/home']);
					this.flashMessage.show(data.msg,{cssClass:'alert-danger',timeout:1500});
					
				}
				else{
					this.validateService.sotreUserData(data.token,data.user);
					this.router.navigate(['/home']);
				}
			});	
		}
	}

}
