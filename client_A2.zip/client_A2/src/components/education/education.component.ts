import { Component } from '@angular/core';

@Component({
  selector: 'education',
  templateUrl: './education.component.html',
  
})

export class EducationComponent { }