import { Component , OnInit, OnChanges } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import {ValidateService} from'../../services/validate.service';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
})

export class HomeComponent {
	
	constructor(private router: Router,
		private validateService:ValidateService) {
	}

	onLogout(){
		
		this.validateService.userLogout();
		this.router.navigate(['/welcomePage']);
	}

}