import { Component } from '@angular/core';

@Component({
  selector: 'entertainment',
  templateUrl: './entertainment.component.html',
  
})

export class EntertainmentComponent { }