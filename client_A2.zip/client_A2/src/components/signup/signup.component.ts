import { Component , OnInit, OnChanges } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import {FlashMessagesService} from 'angular2-flash-messages';
import {ValidateService} from'../../services/validate.service';

@Component({
  selector: 'signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignUpComponent{ 

	//Credential Variables
	userName:string;
	mailId:string;
	passWord:string;
	conPassWord:string;

	//Checkbox Variables
	terms:boolean;
	checkEl:any;
	checkTerms:boolean;

	constructor(private router: Router,private flashMessage:FlashMessagesService,
		private validateService:ValidateService) {
	}

	onSubmit(e) {
		e.preventDefault();
		if(this.userName==undefined||this.userName.length<1||this.mailId==undefined||this.passWord==undefined||this.checkTerms==undefined||this.checkTerms==false){
			this.flashMessage.show('Please fill all the fiels',{cssClass:'alert-danger',timeout:1500});
		}
		else if(this.passWord!=this.conPassWord){
			this.flashMessage.show('Password not mach',{cssClass:'alert-danger',timeout:1500});

		}
		else{
			
			let user={
				userName:this.userName,
				mailId:this.mailId,
				passWord:this.passWord
			}
			console.log("this.userName",user);
			this.validateService.userSignup(user).subscribe(data => {
				if(!data.success){
					this.flashMessage.show('User Name already exists',{cssClass:'alert-danger',timeout:1500});
					
				}
				else{
					this.router.navigate(['/loginPage']);
				}		    	
		    });
		}
	}
}