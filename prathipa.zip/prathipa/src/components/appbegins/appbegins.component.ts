import { Component } from '@angular/core';

@Component({
  selector: 'appbegins',
  templateUrl: './appbegins.component.html',
  styleUrls: ['./appbegins.component.css']
})

export class AppBeginsComponent { }
