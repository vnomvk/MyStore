import { Component } from '@angular/core';

@Component({
  selector: 'profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {

public profile_EditthemeText:boolean =false;
public profile_EditTheme:boolean=true;

constructor(){}

profile_ThemeClick(){
	console.log("fvhsdukrg");
	this.profile_EditthemeText=true;
	this.profile_EditTheme=false;
 }


}
