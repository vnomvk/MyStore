import { Component } from '@angular/core';

@Component({
  selector: 'sports',
  templateUrl: './sports.component.html',
  
})

export class SportsComponent { }