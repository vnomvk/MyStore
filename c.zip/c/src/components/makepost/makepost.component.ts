import { Component } from '@angular/core';

@Component({
  selector: 'makepost',
  templateUrl: './makepost.component.html',
  styleUrls: ['./makepost.component.css']
  
})

export class MakePostComponent {

	postFirstPage:boolean;
	postSecondPage:boolean;

	constructor(){
		this.postFirstPage=true;
		this.postSecondPage=false;
	}

	nextPageFun(ar){
		if(ar=="fwd"){
			this.postFirstPage=false;
			this.postSecondPage=true;
		}
		else{
			this.postFirstPage=true;
			this.postSecondPage=false;
		}
		
	}

}