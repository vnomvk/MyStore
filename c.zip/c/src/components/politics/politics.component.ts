import { Component } from '@angular/core';

@Component({
  selector: 'politics',
  templateUrl: './politics.component.html',
  
})

export class PoliticsComponent { }