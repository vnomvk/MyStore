const express = require('express');
const router = express.Router();
var User= require('../models/user');
var jwt=require('jsonwebtoken');
const config = require('../../config/database');

/* GET api listing. */
router.get('/', (req, res) => {
  res.send('api hello works');
});

//User Signup Route
//http://localhost:port/api/signupData
router.post('/signupData',(req,res,next)=>{

	
	let newUser=new User({
		userName:req.body.userName,
		passWord:req.body.passWord,
		mailId:req.body.mailId
	});
	
	User.addUser(newUser,(err,user)=>{
		if(err){
			res.json({err:err,success:false,msg:'Failed to register user'});
		}else{
			res.json({user:user,success:true,msg:'User registered'});
		}
	});	
	
})

//User Login Route
//http://localhost:port/api/loginData
router.post('/loginData',(req,res,next)=>{

  const username = req.body.userName;
  const password = req.body.passWord;

  User.getUserByUsername(username, (err, user) => {
    if (err) {
          //here you should return by next(err) of callback method
        return next(err);
    }

    if(!user){
      return res.json({success: false, msg: 'User not found'});
    }

    User.comparePassword(password, user.passWord, (err, isMatch) => {
      if (err) {
        //here you should return by next(err) of callback method
        return next(err);
      }

      if(isMatch){
        const token = jwt.sign(user, config.secret, {
          expiresIn: 604800 // 1 week
        });

        res.json({
          success: true,
          token: 'JWT '+token,
          user: {
            id: user._id,
            userName: user.userName,
            mailID: user.mailId
          }
        });
      } else {
        return res.json({success: false, msg: 'Wrong password'});
      }
    });
  });

});


module.exports = router;