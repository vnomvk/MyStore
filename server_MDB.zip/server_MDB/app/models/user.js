var mongoose = require('mongoose');
var bcrypt=require('bcrypt-nodejs');

// define a schema
const UserSchema = mongoose.Schema({
  userName:{type:String,required:true,unique: true},
  passWord:{type:String,required:true},
  mailId:{type:String,required:true,unique: true}
});



const User=module.exports=mongoose.model('User',UserSchema);


module.exports.getUserById=function(id,callback){
  User.findById(id,callback);
}

module.exports.getUserByUsername=function(username,callback){
  const query={userName:username}
  User.findOne(query,callback);
}


//after User variable initialize only can create modules related customised function
module.exports.addUser=function(newUser,callback){
   bcrypt.genSalt(10,(err,salt)=>{
      
      bcrypt.hash(newUser.passWord, salt, null,(err, hash)=>{
        // Store hash in your password DB.
        if(err) {
         //here you should return by  callback(err) of callback method
          return callback(err);
        }else{
          newUser.passWord=hash;
          newUser.save(callback);
        }
      });
   });
}


module.exports.comparePassword = function(candidatePassword, hash, callback){
  bcrypt.compare(candidatePassword, hash, (err, isMatch) => {
    //here you should return by  callback(err) of callback method
    if(err) return callback(err);
    callback(null, isMatch);
  });
}