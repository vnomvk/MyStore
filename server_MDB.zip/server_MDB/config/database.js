module.exports = {
  database: 'mongodb://localhost:27017/myMedia',
  secret: 'yoursecret'
}