// Get dependencies
const express = require('express');
const path = require('path');
const http = require('http');
const bodyParser = require('body-parser');
var morgan  = require('morgan');
const passport=require('passport');

//CORS is a node.js package for providing a Connect/Express 
//middleware that can be used to enable CORS with various options.
var cors = require('cors');
 

const app = express();

///////////***********************MongoDB Part Starts***************************//////////////////////

/**
* getting-started mongoose.The first thing we need to do is include
mongoose in our project and open a connection to the "userCredential" database on our locally
running instance of MongoDB.
*/

var mongoose = require('mongoose');
// Get our API routes
const api = require('./app/routes/api');

mongoose.connect('mongodb://localhost:27017/myMedia',function(err){
	if(err){
		console.log('Not connected to the database',+err);
	} else{
		console.log('Successfully connected to MongoDB');
	}
});





///////////***********************MongoDB Part Ends***************************//////////////////////


//Morgan is used for logging request details.That's it. Everything in your snippet after this are just
//other variations your might want to use
app.use(morgan('dev'));

// Parsers for POST data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Point static path to dist
app.use(express.static(path.join(__dirname,'../client_A2/dist')));

app.use(cors());

// Passport Middleware
app.use(passport.initialize());
app.use(passport.session());

require('./config/passport')(passport);

// Set our api routes
app.use('/api', api);

// Catch all other routes and return the index file
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client_A2/dist/index.html'));
});

/**
 * Get port from environment and store in Express.
 */
const port = process.env.PORT || '5004';
app.set('port', port);

/**
 * Create HTTP server.
 */
const server = http.createServer(app);

/**
 * Listen on provided port, on all network interfaces.
 */
server.listen(port, () => console.log(`API running on localhost:${port}`));