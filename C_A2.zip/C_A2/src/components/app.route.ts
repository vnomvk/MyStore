import { Routes, RouterModule } from '@angular/router';

import { AppComponent }  from './app/app.component';
import { AppBeginsComponent }  from './appbegins/appbegins.component';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './signup/signup.component';
import { ProfileComponent } from './profile/profile.component';
import { HomeComponent } from './home/home.component';

import { DayUpdateComponent } from './dayupdate/dayupdate.component';
import { MyClicksComponent } from './myclicks/myclicks.component';
import { EducationComponent } from './education/education.component';
import { EntertainmentComponent } from './entertainment/entertainment.component';
import { PoliticsComponent } from './politics/politics.component';
import { SportsComponent } from './sports/sports.component';


export const routes: Routes = [
              
  								{ path: '', component:AppBeginsComponent, pathMatch: 'full' },
  								{ path:'welcomePage', component:AppBeginsComponent},
  								{ path: 'loginPage', component: LoginComponent },
  								{ path: 'signupPage', component: SignUpComponent },
                  { path: 'profilePage', component: ProfileComponent },
  								{ path: 'home', component: HomeComponent,
                      children:[
                          { path: '', component: DayUpdateComponent },
                          { path: 'dayupdate', component: DayUpdateComponent },
                          { path: 'myclicks', component: MyClicksComponent },
                          { path: 'education', component: EducationComponent },
                          { path: 'entertainment', component: EntertainmentComponent },  
                          { path: 'politics', component: PoliticsComponent },
                          { path: 'sports', component: SportsComponent }
                      ]
                  }, 					
];

export const appRoutingProviders: any[] = [

];

export const routing = RouterModule.forRoot(routes); 




