import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { HttpModule }    from '@angular/http';

import { AppComponent } from './app/app.component';
import { AppBeginsComponent } from './appbegins/appbegins.component';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { DayUpdateComponent } from './dayupdate/dayupdate.component';
import { MyClicksComponent } from './myclicks/myclicks.component';
import { EducationComponent } from './education/education.component';
import { EntertainmentComponent } from './entertainment/entertainment.component';
import { PoliticsComponent } from './politics/politics.component';
import { SportsComponent } from './sports/sports.component';
import { ProfileComponent } from './profile/profile.component';

import { routing, appRoutingProviders } from './app.route'; 


@NgModule({
  imports:[
    		BrowserModule,
    		routing,
    		HttpModule
  		  ],
  declarations: [
    AppComponent,
    AppBeginsComponent,
    LoginComponent,
    SignUpComponent,
    HomeComponent,
    ProfileComponent,
    DayUpdateComponent,
    MyClicksComponent,
    EducationComponent,
    EntertainmentComponent,
    PoliticsComponent,
    SportsComponent
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
